<?php
SESSION_START();
require 'common.php';
$item_id=$_GET['id'];
$user_id= $_SESSION['user_id'];
$sql="INSERT INTO `users_items` (`user_id`, `item_id`, `status`) VALUES ('$user_id', '$item_id', 'add to cart')";
$result=mysqli_query($conn,$sql);
if($result){
    echo "added value";
}
else{ echo "not added value";}
header("location: product.php")

?>