<?php
SESSION_START();
include 'common.php';
if(!isset($_SESSION['email'])){
    header("location: index.php");
}

?>
<html lang="en">
    <head>
      <!-- Required meta tags -->
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >

      <!-- Bootstrap CSS -->
      
         <link rel="stylesheet"  type="text/css" href="assignment2.CSS">
      <title>our website</title>
      <!-- Optional JavaScript -->
      <!-- jQuery first, then Popper.js, then Bootstrap JS -->
      <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
      <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
      <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
    </head>
    <body>
<?php
include "header.php";
?>


  <br><br>

  <div class="container  m-auto" id="settingcon">
      <h2>Change Password</h2>
      <form action= "settings_scripts.php" method ="POST".>
<div class="form-group">
    <input type="password" placeholder=" Old Password"  name="old_password" class="form-control">
</div>
<div class="form-group">
    <input type="password" placeholder=" New Password"  name="new_password" class="form-control">
</div>
<div class="form-group">
    <input type="password" placeholder="Re-Type New password"  name="Re_Type_New_password" class="form-control">
</div>
<button class="btn btn-primary">Change</button>

      </form>
  </div>
  <?php
  include "footer.php";
  ?>
