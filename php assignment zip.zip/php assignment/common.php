<?php
 $server="localhost";
 $username="root";
 $password="";
 $database="store";
 $conn=mysqli_connect($server,$username,$password,$database);
//  if($conn){echo 'success';}
//  else{echo 'server failed';}
// SESSION_START();
// $email=$_POST['email'];
// $password=$_POST['password'];

?>