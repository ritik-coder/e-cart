<?php

function check_if_added_to_cart($item_id){
include 'common.php';
$user_id=$_SESSION['user_id'];
$sql="SELECT * FROM users_items WHERE item_id='$item_id' AND user_id ='$user_id' AND status='Add to cart'";
$result=mysqli_query($conn,$sql);
$row=mysqli_num_rows($result);
if($row>=1){
return 1;
}
else{return 0;}

}
 ?>

