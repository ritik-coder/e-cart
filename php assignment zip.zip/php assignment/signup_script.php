<?php
require 'common.php';
include 'signup.php';

$email=$_POST["email"];
$password=$_POST["password"];
$cpassword=$_POST["cpassword"];

 $sql="SELECT * FROM `users` WHERE `email`='$email'";
 $result=mysqli_query($conn,$sql);
 $row=mysqli_num_rows($result);

 if($row>0){
     echo "Email id already exist";
 }

 else{if($password==$cpassword){
    $hash=password_hash($password,PASSWORD_DEFAULT);
     $sql="INSERT INTO `users` (`email`, `password`) VALUES ('$email','$hash')";
     $result=mysqli_query($conn,$sql);
     if($result){
         echo "inserted";
                }
      else{
          echo "not inserted";
           }
        }
        else{echo "password not matched";}


      }


 
 ?>