<?php
SESSION_START();
require 'common.php';
if (!isset($_SESSION['email'])){
     header("location: login.php");
}
else{}

?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >

    <!-- Bootstrap CSS -->
    
       <link rel="stylesheet"  type="text/css" href="assignment2.CSS">
    <title>our website</title>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
  </head>
  <body>
<?php
include 'header.php'; ?>
<br><br>
<br><br>
<div class="container" id="cartclass">
<table class="table table-stripped table-hover">
<thead>
<?php
echo '<tr> <th scope="col">id</th><th scope="col">item name</th> <th scope="col">item price</th><th></th> </tr>';?>

</thead>

<tbody>
<?php
$user_id=$_SESSION['user_id'];
$sql="SELECT * FROM `users_items` WHERE `user_id`='$user_id'";
$result=mysqli_query($conn,$sql);
$count=mysqli_num_rows($result);
$add=0;
$id=0;
if($count==0){
  echo "Add items to the cart first!";
}
else{$user_id=$_SESSION['user_id'];
     $sql="SELECT items.name,items.price,users_items.sr
     FROM users_items
     INNER JOIN items ON users_items.item_id = items.id WHERE users_items.user_id='$user_id'
     ";
     $result=mysqli_query($conn,$sql);
    //  $row=mysqli_fetch_assoc($result);
  //if($row['id']==$user_id){
    while($row=mysqli_fetch_assoc($result)){
      $item_name=$row['name'];
      $item_price=$row['price'];
      $users_items_id=$row['sr'];
      $add=$add+$item_price;
      $id++;
    echo '
    <tr><th scope="row">'.$id.'</th> <td>'. $item_name .'</td> <td>'. $item_price .'</td><td><a  href="cart-remove.php?id='.$users_items_id.'" >remove </a></td> </tr>';
    
  }
   echo '<tr><th scope="col"></th><td>total</td><td>Rs /' . $add .'.00 </td><td><a class="btn btn-primary" href="success.php?id='.$user_id.'"> confirm order</a></td></tr><tr>';
 //}
 }

?>
</tbody>
</table>
</div>
<?php include 'footer.php'; ?>