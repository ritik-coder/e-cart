<?php
SESSION_START();
include 'common.php' ;
if(!isset($_SESSION['email'])){
$loggedin=true;
}
else{$loggedin=false;

}

?>

<html lang="en">
    <head>
      <!-- Required meta tags -->
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >
    
  
      <!-- Bootstrap CSS -->
         <link rel="stylesheet"  type="text/css" href="assignment2.CSS">
      <title>our website</title>
      <!-- Optional JavaScript -->
      <!-- jQuery first, then Popper.js, then Bootstrap JS -->
      <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
      <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
      <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
    </head>
    <body>
<?php
include 'header.php';
include 'Check-if-added.php';

?>
  <div class="container">
      <div class="jumbotron">
      <h1>Welcome to our lifestyle store</h1>
      <p>We have the best cameras, watches and shirts for you. No need to hunt around, we have all in one place. </p>
  </div>
  </div>


  <div class="container">
    <div class="text-center">
  <div class="d-flex">


<?php
$sql="SELECT * FROM `items`";
$result=mysqli_query($conn,$sql);
while($row=mysqli_fetch_assoc($result)){
  $item_id=$row['id'];
  $item_name=$row['name'];
  $item_price=$row['price'];  ?>
  

  <div class="img-thumbnail col-md-3 mb-3">
  <img src="img/bootstrap_assignment/<?php echo "$item_id" ;?>.jpg" width="100%" height="180px" >
  <h2><?php echo "$item_name"; ?></h2>
  <p>price:Rs.<?php echo "$item_price";?></p> 
  <?php 
  if(!$loggedin){ ?>
             <p><a href="login.php" role="button" class="btn btn-primary btn-block">Buy Now</a></p> <?php }?>



 <?php if($loggedin){
    
    if(check_if_added_to_cart("$item_id")) { 
 echo '<a href="#" class="btn btn-block btn-success" disabled>Added to cart</a>';
  
} else{?>

  <a href="cart-add.php?id=<?php  echo " $item_id" ;?>" name="add" value="add" class="btn btn-block btn-primary">Add to cart</a> <?php }} ?>

 </div>
  <?php } ?>
                            


</div>
</div>
</div>

