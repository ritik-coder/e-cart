<?php
require 'common.php';
// include 'login.php';
$email=$_POST["email"];
$password=$_POST["password"];



$sql="SELECT * FROM `users` WHERE `email`='$email'";
$result=mysqli_query($conn,$sql);
$num=mysqli_num_rows($result);
if($num==1)
{while($row=mysqli_fetch_array($result))
    {if(password_verify($password,$row['password'])){
        SESSION_START();
        $_SESSION['user_id']=$row['id'];
        $_SESSION['email']=$row['email'];
        header("location: product.php");}
        else{echo "password  not matched";}
     }
}
else{ echo "there is no user with email id and password.";}
   
 ?>
