<?php
SESSION_START();
include 'common.php';
if(!isset($_SESSION['email'])){
    header("location: index.php");
}
$old_password=$_POST['old_password'];
$new_password=$_POST['new_password'];
$email=$_SESSION['email'];
$re_type_password=$_POST['Re_Type_New_password'];
if($new_password==$re_type_password){
$sql="SELECT * FROM `users` WHERE `email`='$email'";
$result=mysqli_query($conn,$sql);
$num=mysqli_num_rows($result);
if($num==1)
{$row=mysqli_fetch_assoc($result);  
   if(password_verify($old_password,$row['password']))
  {$hash=password_hash($new_password,PASSWORD_DEFAULT);
    $sql="UPDATE `users` SET `password`='$hash' WHERE `email`='$email'";
    $result=mysqli_query($conn,$sql);

}
else{ header("location :settings.php");}
}

}

else{echo ' re type password not matched';}

?>