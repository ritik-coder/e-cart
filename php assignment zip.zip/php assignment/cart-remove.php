<?php
SESSION_START();
include 'common.php';
$item_id=$_GET['id'];
$user_id=$_SESSION['user_id'];
$sql="DELETE FROM `users_items` WHERE `sr`='$item_id'";
$result=mysqli_query($conn,$sql);
if($result){
    echo "remove success";
}
else{ echo " not removed";}


 header("location: cart.php");
?>